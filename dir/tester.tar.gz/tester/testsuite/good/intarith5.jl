int main() {
    int x;
    int y;

    x = 10;
    y = 3;

    printInt(x + y);
    printInt(x - y);
    printInt(x * y);
    printInt(x / y);
    printInt(x % y);

    printInt(-x);

    x++;
    printInt(x);

    y--;
    printInt(y);

    return 0;
}
    
    
    

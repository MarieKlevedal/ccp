int main() {
    double dA;
    double dB;
    dA=1.4e-3;
    dB=0.4e-3;
    if (dA-dB == 0.001) {
        printInt(99);
    }
    int iA;
    int iB;
    iA=342;
    iB=5123123;
    printInt(iA-iB);
    return 0;
}

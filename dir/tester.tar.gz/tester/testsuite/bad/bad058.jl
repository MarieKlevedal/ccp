double printInt() {
   return 1;
}
int main() { 
   printInt(1.0);
}

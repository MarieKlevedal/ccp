int main() {
    // Arithmetic operations with cross-types
    int x;
    double y;
    x-y;

    return 0;
}

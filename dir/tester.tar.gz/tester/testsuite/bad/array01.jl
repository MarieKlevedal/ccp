
int main() {
  int[1] a;
  return 0;
}

int main() { 
   int =;
   return 1;
}

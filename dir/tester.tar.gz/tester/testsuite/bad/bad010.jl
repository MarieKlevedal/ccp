int main() {
        if (true)
                return;
	;
        return 1;
}

int main() { 
   int !a;
   return 1;
}

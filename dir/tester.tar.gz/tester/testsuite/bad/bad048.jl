int main() { 
   int a-9;
   return 1;
}

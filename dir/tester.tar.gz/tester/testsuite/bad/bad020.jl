// Compare double with boolean.

int main() {
  if (2.0 == true) {
   printString("foo");
  }
  return 0 ;
}
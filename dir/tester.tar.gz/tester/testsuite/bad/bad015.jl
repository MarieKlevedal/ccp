// passing doubles to printInt().

int main() {
	printInt(1.0);
	return 0 ;
}

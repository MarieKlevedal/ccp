int main() {
      double x ;
      x = 2 * 3.14 ;
      return 0 ;
}

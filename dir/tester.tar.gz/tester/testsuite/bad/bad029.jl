int main() { 
    while(false) return 0;
}

int main(){
  int[] x = new int[10];
  int y = x.hi;
  return 0;
}